import ILLogo from './logo.png';
import ILLogo2 from './logo2.png';

export {ILLogo, ILLogo2};
