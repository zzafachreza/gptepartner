import BottomNavigator from './BottomNavigator';
export {BottomNavigator};
