import React from 'react';
import {StyleSheet, Text, View} from 'react-native';

export default function Info() {
  return (
    <View>
      <Text>test info</Text>
    </View>
  );
}

const styles = StyleSheet.create({});
