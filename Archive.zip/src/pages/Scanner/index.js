import React, {useEffect} from 'react';
import {StyleSheet, Text, View, PermissionsAndroid} from 'react-native';
import {CameraKitCameraScreen, CameraKitCamera} from 'react-native-camera-kit';

export default function Scanner({navigation}) {
  // useEffect(() => {
  //   requestCameraPermission();
  // }, []);

  const barcodeReceived = (result) => {
    // alert(result);

    navigation.navigate('Hasil', {barcode: result});
  };

  return (
    <View
      style={{
        justifyContent: 'center',
        // alignItems: 'center',
      }}>
      {/* <Text
        style={{
          position: 'absolute',
          color: 'white',
          zIndex: 99,
          left: '20%',
          fontSize: 20,
          top: 150,
        }}>
        Scan Barcode Product Pada Kotak
      </Text> */}

      {/* <CameraKitCamera
        ref={(cam) => (this.camera = cam)}
        style={{
          flex: 1,
          backgroundColor: 'white',
        }}
        cameraOptions={{
          flashMode: 'auto', // on/off/auto(default)
          focusMode: 'on', // off/on(default)
          zoomMode: 'on', // off/on(default)
          ratioOverlay: '1:1', // optional
          ratioOverlayColor: '#00000077', // optional
        }}
        onReadCode={(
          event, // optional
        ) => barcodeReceived(event.nativeEvent.codeStringValue)}
        resetFocusTimeout={0} // optional
        resetFocusWhenMotionDetected={true} // optional
      /> */}

      <CameraKitCameraScreen
        actions={{
          rightButtonText: 'Done',
          leftButtonText: 'Cancel',
          centerButtonText: 'test',
        }}
        // onBottomButtonPressed={(event) => alert(event)}
        scanBarcode={true}
        laserColor={'yellow'}
        frameColor={'red'}
        onReadCode={(event) =>
          barcodeReceived(event.nativeEvent.codeStringValue)
        } //optional
        hideControls={true} //(default false) optional, hide buttons and additional controls on top and bottom of screen
        showFrame={true} //(default false) optional, show frame with transparent layer (qr code or barcode will be read on this area ONLY), start animation for scanner,that stoped when find any code. Frame always at center of the screen
        offsetForScannerFrame={30} //(default 30) optional, offset from left and right side of the screen
        heightForScannerFrame={200} //(default 200) optional, change height of the scanner frame
        colorForScannerFrame={'red'} //(default white) optional, change colot of the scanner frame
      />
    </View>
  );
}

const styles = StyleSheet.create({});
